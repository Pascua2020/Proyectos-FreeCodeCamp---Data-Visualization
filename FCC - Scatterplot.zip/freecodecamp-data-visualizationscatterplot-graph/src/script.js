const tooltip = document.getElementById('tooltip');

/*EJ de los datos:
{
    "Time": "36:50",
    "Place": 1,
    "Seconds": 2210,
    "Name": "Marco Pantani",
    "Year": 1995,
    "Nationality": "ITA",
    "Doping": "Alleged drug use during 1995 due to high hematocrit levels",
    "URL": "https://en.wikipedia.org/wiki/Marco_Pantani#Alleged_drug_use"
  },etc.*/

fetch('https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/cyclist-data.json')
  .then(res => res.json())
  .then(res => {
  //console.log("res: ",res)
  /*0: {Time: "36:50", Place: 1, Seconds: 2210, Name: "Marco Pantani", Year: 1995, …},ETC
*/

  createStuff(res.map(r => [
    convertMinAndSec(r.Time), 
    r.Year,
    r.Doping,
    r.Name,
    /*VALORES : r.Time(convert) : Fri Jan 01 2010 00:38:55 GMT-0300 (GMT-03:00) r.Time : 38:55 r.Year : 1994 r.Doping : In 2000 confessed to doping during his career r.Name : Richard Virenque year+1 1995 year-1 1993*/
    /*console.log("r.Time(convert) :",convertMinAndSec(r.Time),
                "r.Time :",r.Time,
                "r.Year :",r.Year,
                "r.Doping :",r.Doping,
                "r.Name :",r.Name,
                "year+1",r.Year+1,
                "year-1",r.Year-1)*/
  ]));
});

function convertMinAndSec(str) {
  // ej valor asignado: 39:50
  // ej valor final: 2010-01-01T03:39.50.000Z
  return new Date(`2010 01 01 00:${str}`);
}

function createInnerHTMLForTooltip(d) {
  /*
d[0] : time
d[1] : year
d[2] : doping?
d[3] : name
*/
  return `
    <p>${d[3]}(${d[1]})</p>
    <p>Time: <strong>${d[0].getMinutes()}:${d[0].getSeconds()}</strong></p>
    ${d[2] ? `<small>${d[2]}</small>` : ''}
  `;
}

function createStuff(data) {
  const width = 800;
  const height = 400;
  const padding = 40;
  
  const circleRadius = 7;
  
  /*The d3.scaleTime() function is used to create and return a new time scale which have the particular domain and range. In this function the clamping is disabled by default.
  
  si no me equivoco,a diferencia del programa anterior se usa scaleTime en ambas escalas,no solo X.*/
  const yScale = d3.scaleTime()
  // recordemos,d[0] = time ( por lo que domain sera tiempo minimo y maximo de la BD.)
      .domain([d3.min(data, d => d[0]), d3.max(data, d => d[0])])
  // padding = 40,height (400) - padding (40) = 360
      .range([padding, height - padding]);
  
  const xScale = d3.scaleTime()
      .domain([
        /* el valor minimo deberia ser el año anterior al minimo y el maximo,el sgiuiente al maximo.
         EJ : si el año es 1995,d3.min = 1994,d3.max = 1996.*/
        d3.min(data, d => new Date(d[1] - 1)), 
        d3.max(data, d => new Date(d[1] + 1)),
      ])
      //.attr("fake",d =>console.log("d3.min",d3.min))
  // padding (40),width (800) - padding(40) = 760
      .range([padding, width - padding]);
  
  /*console.log("d3.min (X)",d3.min(data, d => d[1]),
              "d3.max (X)",d3.max(data, d => d[1]),
              "d3.min (Y)",d3.min(data, d => d[0]),
              "d3.max (Y)",d3.max(data, d => d[0]));*/
  /* d3.min (X) 1994 
  d3.max (X) 2015 
  d3.min (Y) 1994 
  d3.max (Y) Fri Jan 01 2010 00:39:50 GMT-0300 (GMT-03:00)*/
  
  
  const svg = d3.select('#container').append('svg')
          .attr('width', width)
          .attr('height', height);
  
  // create the graph
  /*The stroke attribute is a presentation attribute defining the color (or any SVG paint servers like gradients or patterns) used to paint the outline of the shape;

Note: As a presentation attribute stroke can be used as a CSS property.

The cx attribute define the x-axis coordinate of a center point.

The cy attribute define the y-axis coordinate of a center point.*/
  svg.selectAll('circle') // la forma a mostrar sera un circulo.
    .data(data)
    .enter()
    .append('circle')
    .attr('class', 'dot')
  // test 4. I can see dots, that each have a class of "dot", which represent the data being plotted ( trazado ).
  // test 6. The data-xvalue and data-yvalue of each dot should be within the range of the actual data and in the correct data format. For data-xvalue, integers (full years) or Date objects are acceptable for test evaluation. For data-yvalue (minutes), use Date objects.
    .attr('data-xvalue', d => d[1])
    .attr('data-yvalue', d => d[0])
    .attr('cx', d => xScale(d[1]))
    .attr('cy', d => yScale(d[0]))
  // d[2] : doping , naranja = sin alegaciones de doping,celeste = alegaciones de doping.
    .attr('fill', d => d[2] === '' ? 'blue' : 'red')
    .attr('stroke', 'black') // stroke es el color del contorno del circulo.
    .attr('r', circleRadius)
  
  // MOSTRANDO VALORES:
    //.attr("fake2",d =>(console.log("d: ",d)))
  /*"d: " // [object Array] (4)
[// [object Date] 
"2010-01-01T03:39:50.000Z",2013,"","Nairo Quintana"]*/
  
    /*.attr("fake3",d =>(console.log("data-xvalue",d[1],"data-y-value",d[0],"cx (xScale(d[1])",xScale(d[1]),"cy (yScale(d[0]))",yScale(d[0]),"r ( circleRadius)",circleRadius,"tooltip.style.left",xScale(d[1]) + 10,"tooltip.style.top",yScale(d[0]) - 10 )))*/
  
  /*data-xvalue 2004 
  data-y-value Fri Jan 01 2010 00:39:41 GMT-0300 (GMT-03:00) 
  cx (xScale(d[1]) 384.34782608695656 
  cy (yScale(d[0])) 344 
  r ( circleRadius) 7 
  tooltip.style.left 394.34782608695656 
  tooltip.style.top 334*/
  
  
  /*EJEMPLO VALOR "d" : 
"2010-01-01T03:39:41.000Z",2004,"High Hematocrit during 2005 season, removed by team management","Santos Gonzalez"]

no se que valor tiene i pero al parecer tampoco se usa ( por lo menos dentro del on).
d: data , i : index*/
    .on('mouseover', (d, i) => {
      tooltip.classList.add('show');
      tooltip.style.left = xScale(d[1]) + 10 + 'px';
      tooltip.style.top = yScale(d[0]) - 10 + 'px';
      tooltip.setAttribute('data-year', d[1])
      
      // en innerHTML se guarda el texto que aparece al seleccionar algun circulo en pantalla.
      tooltip.innerHTML = createInnerHTMLForTooltip(d);
  }).on('mouseout', () => {
     tooltip.classList.remove('show');
  });
  
  // format the data
  /*d3-time-format is a JavaScript module used to parse or format dates in various locale-specific representations.
  
  d3-format helps you format numbers for human consumption.
  
  The d3.axis.tickFormat() Function in D3.js is used to control which ticks are labelled. This function is used to implement your own tick format function.
  
  Tick is a modular JavaScript plugin that makes visualizing dynamically changing numbers a breeze.
  
  El método call() llama a una función con un valor dado this y con argumentos provistos individualmente.
  
  sin estos metodos ( timeFormat y format ) la hora,minutos y año no tienen formato al mostrarse.
  
  test 9. I can see multiple tick labels on the y-axis with "%M:%S" time format.*/
  const timeFormatForMinAndSec = d3.timeFormat("%M:%S");
  const timeFormatForYear = d3.format("d");

  /* create axis
  Eje X : Año
  Eje Y : Minutos y Segundos
  Sin el tickFormat los valores en las lineas ( como años ) se muestran mal.
  */
  const xAxis = d3.axisBottom(xScale)
    .tickFormat(timeFormatForYear)
  const yAxis = d3.axisLeft(yScale)
    .tickFormat(timeFormatForMinAndSec)
  
  svg.append('g')
    .attr('id', 'x-axis')
  // translate = X:0,Y:360
    .attr('transform', `translate(0, ${height - padding})`)
    .call(xAxis);
  
  svg.append('g')
    .attr('id', 'y-axis')
  // translate = X:40,Y:0
    .attr('transform', `translate(${padding}, 0)`)
    .call(yAxis)
  //console.log(yAxis)
}