const tooltip = document.getElementById('tooltip');

/*Cuando se llama a una función async, esta devuelve un elemento Promise. Cuando la función async devuelve un valor, Promise se resolverá con el valor devuelto. Si la función async genera una excepción o algún valor, Promise se rechazará con el valor generado.

run : It can be used to invoke (call) a method with an owner object as an argument (parameter). With call() , an object can use a method belonging to another object.

a expresión await provoca que la ejecución de una función async sea pausada hasta que una Promise sea terminada o rechazada, y regresa a la ejecución de la función async después del término. Al regreso de la ejecución, el valor de la expresión await es la regresada por una promesa terminada.

Si la Promise es rechazada, el valor de la expresión await tendrá el valor de rechazo.*/
async function run() {
  const eduResp = await fetch('https://cdn.freecodecamp.org/testable-projects-fcc/data/choropleth_map/for_user_education.json');
  /*EJ VALORES : 
  {
		"fips": 1001,
		"state": "AL",
		"area_name": "Autauga County",
		"bachelorsOrHigher": 21.9
	},*/
  const educations = await eduResp.json();

  const countiesResp = await fetch('https://cdn.freecodecamp.org/testable-projects-fcc/data/choropleth_map/counties.json');
  /*EJ VALORES : 
  "type": "Topology",
	"objects": {
		"counties": {
			"type": "GeometryCollection",
			"geometries": [
				{
					"type": "Polygon",
					"id": 5089,
					"arcs": [
						[
							0,
							1,
							2,
							3,
							4
						]
					]
				},*/
  const counties = await countiesResp.json();

  const width = 960;
  const height = 600;

  /*d3.geoPath([projection[, context]]) <>

Creates a new geographic path generator with the default settings. If projection is specified, sets the current projection. If context is specified, sets the current context.*/
  const path = d3.geoPath();
  
  //console.log(path)
  /*TopoJSON is an extension of GeoJSON that encodes topology. Rather than representing geometries discretely, geometries in TopoJSON files are stitched ( cosido ) together from shared line segments called arcs. 
  
  Topologia : Ciencia que estudia los razonamientos matemáticos, prescindiendo de los significados concretos.
  
  topojson.feature - convert TopoJSON to GeoJSON.
  
  GeoJSON​ es un formato estándar abierto diseñado para representar elementos geográficos sencillos, junto con sus atributos no espaciales, basado en JavaScript Object Notation.​​
  
  .features is not a method, that's just a property of the GeoJSON object. It is created by topojson.feature (which, by the way, is a real method).*/
  const data = topojson.feature(counties, counties.objects.counties).features;
  // recordemos que counties es el archivo .json,que contiene al tipo objects que a su vez contiene al tipo counties.
  
  // console.log("data",data).
  // data contiene 3142 arrays.
  
  const minEdu = d3.min(educations, edu => edu.bachelorsOrHigher);
  const maxEdu = d3.max(educations, edu => edu.bachelorsOrHigher);
  const step = (maxEdu - minEdu) / 8;

  // muestro valores
 
  /*"minEdu" 2.6 
  "maxEdu" 75.1 
  "step" 9.0625 
  "d3.range(minEdu, maxEdu, step)" // [object Array] (8)
[2.6,11.6625,20.725,29.7875,38.85,47.9125,56.975,66.0375] "d3.schemePurples[9]" // [object Array] (9)
["#fcfbfd","#efedf5","#dadaeb","#bcbddc","#9e9ac8","#807dba","#6a51a3","#54278f","#3f007d"]*/
  console.log("minEdu",minEdu,"maxEdu",maxEdu,"step",step,"d3.range(minEdu, maxEdu, step)",d3.range(minEdu, maxEdu, step),"d3.schemePurples[9]",d3.schemePurples[9])
  
  /*The d3.scaleThreshold() function in D3.js is used to create and return a new threshold scale ( escala de umbral ) that has the specified domain and range. The default value of domain is [0.5] and that of range is [0, 1].
  
  schemePurples:
  Given a number t in the range [0,1], returns the corresponding color from the “Purples” sequential color scheme represented as an RGB string.*/
  const colorsScale = d3.scaleThreshold()
  // a diferencia del proyecto anterior,domain tiene 3 valores y no 2.
    .domain(d3.range(minEdu, maxEdu, step))
    .range(d3.schemeBlues[6]);
  
  //console.log(colorsScale)
  const colors = [];
  
  for(let i=minEdu; i<=maxEdu; i+=step) {
    // muestro bucle for
    console.log("for : ","i",i,"minEdu",minEdu,"maxEdu",maxEdu,"step",step,"colors(i)",colors.push(i))
    /*"for : " 
    "i" 2.6 
    "minEdu" 2.6 
    "maxEdu" 75.1 
    "step" 9.0625 
    "colors(i)" 1*/
    
    colors.push(i);
  }
  
  const svg = d3.select('#container').append('svg')
    .attr('width', width) // 960
    .attr('height', height); // 600
  
  svg.append('g')
    .selectAll('path')
    .data(data)
    .enter()
    .append('path')
    .attr('class', 'county')
    .attr('fill', d => colorsScale(educations.find(edu => edu.fips === d.id).bachelorsOrHigher))
  
  // MUESTRO VALORES
  
    //.attr("fake", d=> console.log("(educations.find(edu => edu.fips === d.id).bachelorsOrHigher)",educations.find(edu => edu.fips === d.id).bachelorsOrHigher))
  // valor de ej: 22.5
  
    .attr('d', path)
    .attr('data-fips', d => d.id)
    .attr('data-education', d => educations.find(edu => edu.fips === d.id).bachelorsOrHigher)
  
  
  // MUESTRO VALORES
    //.attr("fake2", d=> console.log("d.geometry",d.geometry)) // muchos array
  
  /*.attr("fake3", d=> console.log("fill:",colorsScale(educations.find(edu => edu.fips === d.id).bachelorsOrHigher),
                                "data-fips:",d.id,
                                "data-education:",educations.find(edu => edu.fips === d.id).bachelorsOrHigher))*/
  
  /*EJ : fill: #3182bd 
  data-fips: 39103 
  data-education: 29.9*/
  
    .on('mouseover', (d, i) => {
    
      const { coordinates } = d.geometry;
    
      const [x, y] = coordinates[0][0];
    //valor de EJ: [82.37379936434536,239.94931625503494]

      const education = educations.find(edu => edu.fips === d.id);

      tooltip.classList.add('show');
      tooltip.style.left = x - 50 + 'px';
      tooltip.style.top = y - 50 + 'px';
    
    // muestro coordenadas x,y
    console.log("coordinates[0][0]   (x,y) : ",coordinates[0][0],"tooltip.style.left : ",x-50,"tooltip.style.top : ",y-50)
    
      tooltip.setAttribute('data-education', education.bachelorsOrHigher);

    /*EJ de valores (innerHtml):
Miami-Dade County - FL
26.4*/
    
      tooltip.innerHTML = `
<p>${education.area_name} - ${education.state}</p>
<p>${education.bachelorsOrHigher}%</p>
      `;
  }).on('mouseout', () => {
    tooltip.classList.remove('show');
  });

  // create the legend
  const legendWidth = 200;
  const legendHeight = 30;

  const legendRectWidth = legendWidth / colors.length; // 11.11

  // muestro valores
 console.log("legendWidth",legendWidth,"legendHeight",legendHeight,"colors.length",colors.length,"legendRectWidth",legendRectWidth)
  
  const legend = d3.select('#container')
    .append('svg')
    .attr('id', 'legend')
    .attr('class', 'legend')
    .attr('width', legendWidth) // 200
    .attr('height', legendHeight) // 30
   
  legend.selectAll('rect')
    .data(colors)
    .enter()
    .append('rect')
    .attr('x', (_, i) => i * legendRectWidth) // si i = 1,x = 11.11
    .attr('y', 0)
    .attr('width', legendRectWidth) // 11.11
    .attr('height', legendHeight) // 30
    .attr('fill', c => colorsScale(c))
  
  // muestro valores de legend
    .attr("fake3", (_,i) => console.log("Valores de x (legend): ","_ : ",_,"i : ",i))
  
  // ej : "Valores de x (legend): " "_ : " 56.975 , "i : " 12
  
  .attr("fake4", c => console.log("fill (sin colorScale):",c,"fill ( con colorScale)",colorsScale(c)))
  
 /*"fill (sin colorScale):" 75.1 
 "fill ( con colorScale)" "#08519c"*/
}

run();