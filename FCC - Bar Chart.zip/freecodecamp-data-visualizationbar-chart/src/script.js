const tooltip = document.getElementById('tooltip'); // si no me equivoco esto se asocia con el tooltip del html.
console.log("tooltip: ",tooltip)
/*
La API Fetch proporciona una interfaz JavaScript para acceder y manipular partes del canal HTTP, tales como peticiones y respuestas. También provee un método global fetch() (en-US) que proporciona una forma fácil y lógica de obtener recursos de forma asíncrona por la red.*/
fetch('https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/GDP-data.json')
  .then(res => res.json())
  .then(res => {
  const { data } = res;
  /*
  Valores de ejemplo de Data(año,gdp):
  "data": [
    [
      "1947-01-01",
      243.1
    ],
    [
      "1947-04-01",
      246.3
    ],*/

  createStuff(data.map(d => [d[0], d[1]]));
 
})

function createStuff(data) {

  const width = 800;
  const height = 400;
  const padding = 40;
  
  // data.length es equivalente a 275.
  // 800 / 275 : 2.90
  const barWidth = width / data.length;
  
  console.log("data[0]",data[0])
  console.log("data[1]",data[1])
  console.log("data[274]",data[274])
   // VALORES DE EJEMPLO : ["2015-07-01",18064.7]
  console.log("createStuff(data):","width",width,"height",height,"padding",padding,"barWidth",barWidth)
  // VALORES DE EJEMPLO : "createStuff(data):" "width" 800 "height" 400 "padding" 40 "barWidth" 2.909090909090909
  
  /*D3.js is a JavaScript library for manipulating documents based on data. D3 helps you bring data to life using HTML, SVG, and CSS. D3’s emphasis on web standards gives you the full capabilities of modern browsers without tying yourself to a proprietary framework, combining powerful visualization components and a data-driven approach to DOM manipulation.
  
  d3.scaleLinear constructs creates a scale with a linear relationship between input and output.
  
   Domain represents the boundaries within which your data lies. e.g. If I had an array of numbers with no number smaller than 1 and no number larger than 100, my domain would be 1 to 100.
   
   you need to specify the boundaries within which your original data can be transformed. These boundaries are called the range.
   
   d3.min returns the minimum value from the given iterable of values. For example, if you pass it an array of numbers, it returns the smallest number.
   
   A mirror of d3.min is d3.max, which returns the maximum value. d3.extent returns [min, max] in a single pass over the input, which is particularly convenient if you wish to set a scale’s domain.
   
  */
  
  const yScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d[1])])
      .range([height - padding, padding])
  
  //console.log(yScale)
  // SI IMPRIMO ESTOS FAKE,LOS SIGUIENTES NO SE MUESTRAN
      // "d3.max(data, d => d[1])" = 18064.7
      //.attr("fake10", console.log("data",data));
  
  // VALORES DE EJEMPLO (data):
// ["1947-01-01",243.1]

  /*
  el d3 max significa que la escala y,que esta en la izquierda,el numero maximo sera el equivalente al maximo de billones ( que esta por 15000 billones).
  d[1] son los billones.
  sin range y/o domain no se limitan los valores a buscar.
  height(400) - padding (40) = 360*/
  
  // si se usa scaleLinear en vez de scaleTime el eje x falla en el test 10.
  const xScale = d3.scaleTime()
      .domain([d3.min(data, d => new Date(d[0])), d3.max(data, d => new Date(d[0]))])
      .range([padding, width - padding]);
      
  /* en domain se pone el año que comienza la escala y el que termina.por lo tanto comienza con un nuevo objeto que empieza por los años 40 y termina con un nuevo objeto que termina alrededor de 2015.
  d[0] son los años.
  
 sin range no aparece la escala X y los graficos se muestran mal.sin domain no hay graficos y la escala X se muestra mal.*/
  
  /*The d3.select() function in D3.js is used to select the first element that matches the specified selector string. If any element is not matched then it returns the empty selection. If multiple elements are matched with the selector then only the first matching element will be selected.
  
  append() - Appends a new element with the specified name as the last child of each element in the current selection, returning a new selection containing the appended elements.
  
  D3 provides the ability to set attributes of a selected element using the attr() function. This function takes two parameters:

Attribute Name - For example, "r" to set an SVG circle's radius.
Value or An accessor function - For example "10" to set the radius to 10 or an accessor that sets the value per data point based on the data.*/
  
  const svg = d3.select('#container').append('svg')
          .attr('width', width)
          .attr('height', height)
          .attr("fake3", console.log("svg (con valores): width",width,"height",height));

  // sin los attr se ve cortado.sin select no se ve absolutamente nada.

  /*svg.selectAll('rect') tells the browser to find the svg element and look inside it for any rectangles. If it finds rectangles, it returns them in a selection that is an array of elements. If it doesn’t find any, it returns an empty selection, which is what will happen in this case.
  
  data-* The data-* SVG attributes are called custom data attributes. They let SVG markup and its resulting DOM share information that standard attributes can't, usually for scripting purposes. Their custom data are available via the SVGElement interface of the element the attributes belong to, with the SVGElement.
  
  .enter() creates the initial join of data to elements, creating one circle element for every data element in the array.
  
  Scale functions are JavaScript functions that:

take an input (usually a number, date or category) and
return a value (such as a coordinate, a colour, a length or a radius)
They’re typically used to transform (or ‘map’) data values into visual variables (such as position, length and colour).

Date : Si no proporciona argumentos, el constructor crea un objeto Date con la hora y fecha de hoy según la hora local.

sin rect no hay ningun grafico ni linea en el cuadrado,es decir,esta vacio.

sin el metodo on no aparecen las lineas con los numeros.

sin innerHtml no aparecen los datos dentro del cuadrado mini al seleccionar una parte del grafico.

sin data los graficos estan vacios.sin append no hay escala ni nada.
recordemos que d[0] son los años ( data-date) y d[1] son los billones ( gdp ).

barWidth = 2.90,padding = 40 ( esto creo que es para darle espacio suficiente al grafico ).

height = 360.yScale(d[1] tiene que ser cada gdp de cada año.
en height,sin el -padding la grafica se muestra por debajo de la linea X.

con fake imprimo valores en pantalla.*/
  svg.selectAll('rect')
    .data(data)
    .enter()
    .append('rect')
    .attr('class', 'bar') // test 5 : My chart should have a rect element for each data point with a corresponding class="bar" displaying the data.
    .attr('data-date', d => d[0])
    .attr('data-gdp', d => d[1])
    .attr('x', d => xScale(new Date(d[0])))
    .attr('y', d => yScale(d[1]))
    .attr('width', barWidth)
    .attr('height', d => height - yScale(d[1]) - padding)
  
  // MOSTRAR VARIABLES CON FAKE
  
    //.attr("fake", d=> console.log("rect (sin valores):",d))
  
  // VALOR DE EJEMPLO : ["2015-07-01",18064.7]
  
  
  
    //.attr("fake2", d=> console.log("rect (valores) - data-date",d[0],"data-gdp",d[1],"x",xScale(new Date(d[0])),"y",yScale(d[1]),"width",barWidth,"height",(height - yScale(d[1]) - padding)),"yScale",yScale)
  
  // VALOR DE EJEMPLO 2: "rect (valores) - data-date" "2015-07-01" "data-gdp" 18064.7 "x" 760 "y" 40 "width" 2.909090909090909 "height" 320
  
  // height (400) - yScale(d[1]) (40) - padding (40) = 320
  
    .on('mouseover', (d, i) => {
    
    /*The element's classList property returns the live collection of CSS classes of the element. Use add() and remove() to add CSS classes to and remove CSS classes from the class list of an element. Use replace() method to replace an existing class with a new one.
    
    The style read-only property returns the inline style of an element in the form of a CSSStyleDeclaration object that contains a list of all styles properties for that element with values assigned for the attributes that are defined in the element's inline style attribute.
    
    Establece el valor de un atributo en el elemento indicado. Si el atributo ya existe, el valor es actualizado, en caso contrario, el nuevo atributo es añadido con el nombre y valor indicado.

Para obtener el valor actual de un atributo, se utiliza getAttribute(); para eliminar un atributo, se llama a removeAttribute().

La propiedad Element.innerHTML devuelve o establece la sintaxis HTML describiendo los descendientes del elemento.

Al establecerse se reemplaza la sintaxis HTML del elemento por la nueva.

The on() method attaches one or more event handlers for the selected elements and child elements. As of jQuery version 1.7, the on() method is the new replacement for the bind(), live() and delegate() methods. 

d (un valor de ejemplo) = 1978-10-01",2482.2
d[0] = 1978-10-01
d[1] = 2482.2*/
      dG=d;
      iG=i;
    
      tooltip.classList.add('show');
      tooltip.style.left = i * barWidth + padding * 2 + 'px';
    // i = 100 en 1972-01-01
    // left = 100 * 2.90 + 40 * 2
    // 290 + 80 = 370
    // creo que el valor de i va desde 0 a 275 aproximadamente.
      tooltip.style.top = height - padding * 4 + 'px';
      // top = 240px
    console.log("left",i * barWidth + padding * 2,"top",height - padding * 4)
      tooltip.setAttribute('data-date', d[0])
      
      tooltip.innerHTML = `
        <small>"left:"${tooltip.style.left}</small>
        <small>"top:"${tooltip.style.top}</small>
        <small>d:${d}</small>
        <small>i:${i}</small>
        <small>d[0] (año):${d[0]}</small>
        <small>d[1] (gdp):$${d[1]} billions</small>
      `;
  })
    .attr("fake4", console.log("mouseover"))
    .on('mouseout', () => {
     tooltip.classList.remove('show');
  }
       ).attr("fake5", console.log("mouseout"));

  // d[0] es el año,mes y dia,d[1] son los billones.
  
  // create axis
  const xAxis = d3.axisBottom(xScale)

  /*d3.axisBottom(scale)

Constructs a new bottom-oriented axis generator for the given scale, with empty tick arguments, a tick size of 6 and padding of 3. In this orientation, ticks are drawn below the horizontal domain path.

d3.axisLeft(scale)

Constructs a new left-oriented axis generator for the given scale, with empty tick arguments, a tick size of 6 and padding of 3. In this orientation, ticks are drawn to the left of the vertical domain path.*/
  const yAxis = d3.axisLeft(yScale)
  //console.log(yAxis)

  // La function de CSS translate() recoloca un elemento en el eje horizontal y/o vertical. Su resultado es de tipo <transform-function>.
  svg.append('g')
  // test 2 : My Chart should have a <g> element x-axis with a corresponding id="x-axis".
    .attr('id', 'x-axis')
  // test 4 : Both axes should contain multiple tick labels, each with the corresponding class="tick".
  // "#x-axis .tick"
    .attr('transform', `translate(0, ${height - padding})`)
  // transform seria ( translate(x = 0,y = 360))
    .attr("fake6", console.log("id","transform"))
    .call(xAxis)
    ;
  /*The call() method is a predefined JavaScript method. It can be used to invoke (call) a method with an owner object as an argument (parameter). With call() , an object can use a method belonging to another object.*/
  
  svg.append('g')
    .attr('id', 'y-axis')
    .attr('transform', `translate(${padding}, 0)`)
  // translate ( x = 40,y = 0)
    .call(yAxis)
  //console.log(yAxis)
  // sin los metodos call no aparecen lineas con los numeros.

}