const tooltip = document.getElementById('tooltip');

const colors = ["#67001f","#b2182b","#d6604d","#f4a582","#fddbc7","#f7f7f7","#d1e5f0","#92c5de","#4393c3","#2166ac","#053061"];
/* Ver colores ( https://www.colorhexa.com/ )
#67001f = very dark pink
#b2182b = dark red
#d6604d = moderate red
#f4a582 = soft orange
#fddbc7 = very soft orange
#f7f7f7 = very light gray
#d1e5f0 = light grayish blue
#92c5de = very soft blue
#4393c3 = moderate blue
#2166ac = dark blue
#053061 = very dark blue
*/

const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

console.log("colors",colors,"months",months)

fetch('https://raw.githubusercontent.com/FreeCodeCamp/ProjectReferenceData/master/global-temperature.json')
  .then(res => res.json())
  .then(res => {
  const { baseTemperature, monthlyVariance } = res;
  
 /*EJ de valores:
 "baseTemperature": 8.66,
  "monthlyVariance": [
    {
      "year": 1753,
      "month": 1,
      "variance": -1.366
    }*/
  
  console.log("res",res)
  
  createStuff(monthlyVariance.map(d => ({
    // EJ : temp = 8.66 - (-1.366)
    ...d, 
    temp: baseTemperature - d.variance
  })
                                 ));
})

/*Function variance
Compute the variance of a matrix or a list with values. In case of a (multi dimensional) array or matrix, the variance over all elements will be calculated.*/

function createStuff(data) {
  const width = 800;
  const height = 400;
  const padding = 60;
  
  /* 400 - (2 * 60 ) / 12
 400-120 / 12
 280/12 = 23.3*/
  const cellHeight = 
        (height - (2*padding))
  / 12;
  /*800 / math.floor( 3153 / 12 )
  800 / math.floor ( 262,75 )
  800 / 262 = 3,05*/
  const cellWidth = width / Math.floor(data.length / 12);
  
  console.log("width",width,"height",height,"padding",padding,"cellHeight",cellHeight,"cellWidth",cellWidth,"data.length",data.length,"math.floor(262,75)",Math.floor(262,75));
  
  const yScale = d3.scaleLinear()
  // va de 1 (january) a 12 (december) porque son los meses.
      .domain([1, 12])
  // padding(60),height(800)-60 = 740
      .range([padding, height - padding]);
  
  const xScale = d3.scaleTime()
      .domain([
        // los años van de 1753 a 2015.
        d3.min(data, d => d.year), 
        d3.max(data, d => d.year)
       ])
  // 60,width(400) - 60 = 340
      .range([padding, width - padding]);

  const tempScale = d3.scaleLinear()
  // recordar que temp es la temperatura base - la variacion de cada una,por lo que se tomara el valor minimo y maximo.  
  .domain([
      d3.min(data, d => d.temp), 
      d3.max(data, d => d.temp)
    ])
  // el rango son los colores de la temperatura.
    .range([0, 10]);
  
  const svg = d3.select('#container').append('svg')
  // width = 800,height = 400
          .attr('width', width)
          .attr('height', height);
  
/*The mouseover event is fired at an Element when a pointing device (such as a mouse or trackpad) is used to move the cursor onto the element or one of its child elements.

data-temp : temperatura.

class: Assigns a class name or set of class names to an element. You may assign the same class name or names to any number of elements, however, multiple class names must be separated by whitespace characters.*/
  
  svg.selectAll('rect')
    .data(data)
    .enter()
    .append('rect')
    .attr('class', 'cell')
    .attr('data-month', d => d.month - 1)
    .attr('data-year', d => d.year)
    .attr('data-temp', d => d.temp)
    .attr('fill', d => colors[Math.floor(tempScale(d.temp))])
  .attr('x', d => xScale(d.year))
    /*.attr('x', d => {
     console.log("valor de xScale:",xScale(d.year));
     return xScale(d.year);
   })*/
    .attr('y', d => yScale(d.month - 1))
   /*.attr('y', d => {
      console.log("valor de yScale:",yScale(d.month-1));
      return yScale(d.month-1);
    })*/
  /*
    .attr('y', d => yScale(d.month - 1))*/
    .attr('width', cellWidth)
    .attr('height', cellHeight)
  
  // Muestro valores del rectangulo.
  
    //.attr("fake", d=> console.log("rect (sin valores):",d))
  /*rect (sin valores): 
Object
month: 3
temp: 7.599
variance: 1.061
*/
  
  /*.attr("fake2", d=> console.log("rect (con valores):","data-month",d.month-1,"data-year",d.year,"data-temp",d.temp,"fill",colors[Math.floor(tempScale(d.temp))],"x",xScale(d.year),"y",yScale(d.month - 1) - cellHeight,"width",cellWidth,"height",cellHeight))*/
  
  /*rect (con valores): 
  data-month 11 
  data-year 2014 
  data-temp 7.431 
  fill #f4a582 
  x 737.4045801526718 
  y 291.2121212121212 
  width 3.053435114503817 
  height 23.333333333333332*/
  
 /* .attr("fake3", d=> console.log("valores de colores:","d.temp",d.temp,"tempScale(d.temp)",tempScale(d.temp),"Math.floor(tempScale(d.temp)",Math.floor(tempScale(d.temp)),"colors[etc...]",colors[Math.floor(tempScale(d.temp))]))*/
  
  /*valores de colores: 
  d.temp 8.028 
  tempScale(d.temp) 3.7659783677482794 Math.floor(tempScale(d.temp) 3 
  colors[etc...] #f4a582*/
  
    .on('mouseover', (d, i) => {
      tooltip.classList.add('show');
      tooltip.style.left = xScale(d.year) - 60 + 'px'; // EJ : 680px en 2015(Enero)
      tooltip.style.top = yScale(d.month - 1) - 60 + 'px'; // EJ : 0px en 2015(Enero)
      tooltip.setAttribute('data-year', d.year); // EJ : 2015

      tooltip.innerHTML = `
        <p>${d.year} - ${months[d.month - 1]}</p>
        <p>${d.temp}℃</p>
        <p>${tooltip.style.left}</p>
        <p>${tooltip.style.top}</p>
        <p>Color:${colors[Math.floor(tempScale(d.temp))]}</p>
      `;
  }).on('mouseout', () => {
     tooltip.classList.remove('show');
  });
  
  // create axis
  const xAxis = d3.axisBottom(xScale)
    .tickFormat(d3.format('d'));
  
  const yAxis = d3.axisLeft(yScale)
    .tickFormat((month) => {
    const date = new Date(0);
      /*The setUTCMonth() method sets the month for a specified date according to universal time.*/
    date.setUTCMonth(month);
      console.log("new Date(0) : ",new Date(0),"month : ",month,"date.setUTCMonth(month) : ",date.setUTCMonth(month),"d3.timeFormat('%B')(date) : ",d3.timeFormat('%B')(date))
      
      /*new Date(0) :  Wed Dec 31 1969 21:00:00 GMT-0300 (GMT-03:00) 
      month :  12 
      date.setUTCMonth(month) :  63072000000 d3.timeFormat('%B')(date) :  December*/
    return d3.timeFormat('%B')(date);
  });
  
  svg.append('g')
    .attr('id', 'x-axis')
    .attr('transform', `translate(0, ${height - padding})`)
  // padding = 60,height = 400
  // translate ( 0,340 )
    .call(xAxis);
  
  svg.append('g')
    .attr('id', 'y-axis')
    .attr('transform', `translate(${padding}, ${-cellHeight})`)
  // translate ( 60,cellHeight : 23.3 )
    .call(yAxis);
  
  // create the legend
  const legendWidth = 200;
  const legendHeight = 50;
  
  const legendRectWidth = legendWidth / colors.length; // 18.18
  console.log("legendWidth",legendWidth,"legendHeight",legendHeight,"colors.length",colors.length,"legendRectWidth",legendRectWidth)
  
  const legend = d3.select('body')
    .append('svg')
    .attr('id', 'legend')
    .attr('width', legendWidth) // 200
    .attr('height', legendHeight) // 50
    .selectAll('rect')
    .data(colors)
    .enter()
    .append('rect')
  // i = index
    .attr('x', (_, i) => i * legendRectWidth) // sin esto solo hay una barra
    //.attr("fake3", (_,i) => console.log("Valores de x (legend): ","_ : ",_,"i : ",i))
  // ej : "Valores de x (legend): " 
  // "_ : " "#4393c3" , "i : " 8
    .attr('y', 0)
    .attr('width', legendRectWidth) // 18.18
    .attr('height', legendHeight) // 50
    .attr('fill', c => c) // sin fill la barra de abajo no tiene ningun color.
    .attr("fake4", c => console.log("fill (c):",c))
  // ej : "fill (c):" "#053061"
    /*The fill attribute has two different meanings. For shapes and text it's a presentation attribute that defines the color (or any SVG paint servers like gradients or patterns) used to paint the element; for animation it defines the final state of the animation.*/
}