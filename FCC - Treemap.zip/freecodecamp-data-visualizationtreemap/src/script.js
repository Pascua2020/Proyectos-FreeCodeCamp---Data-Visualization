const tooltip = document.getElementById('tooltip');

/*Cuando se llama a una función async, esta devuelve un elemento Promise. Cuando la función async devuelve un valor, Promise se resolverá con el valor devuelto. Si la función async genera una excepción o algún valor, Promise se rechazará con el valor generado.

Una función async puede contener una expresión await, la cual pausa la ejecución de la función asíncrona y espera la resolución de la Promise pasada y, a continuación, reanuda la ejecución de la función async y devuelve el valor resuelto.*/

async function run() {
  /*EJ valores:
  {
    "name": "Kickstarter",
    "children": [{
                "name": "Product Design",
                "children": [{
                    "name": "Pebble Time - Awesome Smartwatch, No Compromises",
                    "category": "Product Design",
                    "value": "20338986"
                },*/
  const kickRes = await fetch('https://cdn.freecodecamp.org/testable-projects-fcc/data/tree_map/kickstarter-funding-data.json');
  const kickstarter = await kickRes.json(); // si borro await de kickRes,los valores name,category y value son "undefined" y la grafica es de un solo color ( celeste ).

  //console.log("kickstarter : ",kickstarter)
  
  const width = 960;
  const height = 600;
  
  /*The d3.schemeCategory10 method in D3.js is used to return an array of ten categorical colors which is returned as RGB hexadecimal strings.*/
  const color = d3.scaleOrdinal(d3.schemePaired);
  
  console.log("d3.schemeCategory10",d3.schemeCategory10)
  /*"d3.schemeCategory10" // [object Array] (10)
["#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd","#8c564b","#e377c2","#7f7f7f","#bcbd22","#17becf"]*/
  
  const svg = d3.select('#container').append('svg')
    .attr('width', width) // 960
    .attr('height', height); // 600
  
  /*A Treemap displays hierarchical data as a set of nested ( anidado ) rectangles. Each group is represented by a rectangle, which area is proportional to its value. 
  
   The size() function is an inbuilt function which is used to set the width and height of the element. 
   
The padding properties define the space between the element border and the element content. 

La pseudo-clase :root de CSS selecciona el elemento raíz de un árbol que representa el documento. En HTML, :root representa el elemento <html> y es idéntico al selector html, excepto que su especificidad es mayor.

A d3.hierarchy is a nested data structure representing a tree: each node has one parent node (node.parent), except for the root; likewise, each node has one or more child nodes (node.children), except for the leaves. In addition, each node can have associated data (node.data) to store whatever additional fields you like.

d3.sum computes the sum of an array of numbers.*/
  const treemap = d3.treemap()
    .size([width, height]) // 960,600
    .padding(1) // sin el padding los cuadrados pierden formato.
  
  //console.log("treemap",treemap)
  
  const root = d3.hierarchy(kickstarter) // hierarchy = tree
    .sum(d => d.value) // sin sum el diagrama queda en color negro ( es decir,no se dibuja ningun cuadrado).
  
  //console.log(d3.sum(d => d.value))
  // se debe hacer click derecho,boton "inspeccionar" y luego seleccionar "console" para poder ver los valores de root y treemap(root) ( son muy grandes como para verlos en la consola).
  //console.log("root",root,"treemap(root)",treemap(root))
  treemap(root); // recordemos que treemap = d3.treemap(),root = d3.hierarchy(kickstarter)
  
  /*The node.leaves() function in d3.js is used to return an array of leaf nodes ( nodos de hoja ) of the given hierarchical data in traversal ( recorrido ) order.*/
  const cell = svg.selectAll('g')
    .data(root.leaves())
    .enter().append('g')
  // .enter() creates the initial join of data to elements.
  // Appends ( adjunta ) a new element with the specified name as the last child of each element in the current selection, returning a new selection containing the appended elements.
    .attr('transform', d => `translate(${d.x0}, ${d.y0})`)
  //.attr('fake', d => console.log("d.x0",d.x0,"d.y0",d.y0));
  // EJ : "d.x0" 923.5362329716062 
  // "d.y0" 530.6951293673139
  
  const tile = cell.append('rect')
    .attr('class', 'tile')
    .attr('data-name', d => d.data.name)
    .attr('data-category', d => d.data.category)
    .attr('data-value', d => d.data.value)
    .attr('width', d => d.x1 - d.x0)
    .attr('height', d => d.y1 - d.y0)
    .attr('fill', d => color(d.data.category))
  
   /*.attr('fake', d => console.log("data-name : ",d.data.name,"data-category : ",d.data.category,"data-value : ",d.data.value,"width : ",d.x1-d.x0,"height : ",d.y1-d.y0,"fill : ",color(d.data.category)))*/
  
  /*EJ : "data-name : " "The uKeg Pressurized Growler for Fresh Beer" 
  "data-category : " "Drinks" 
  "data-value : " "1559525" 
  "width : " 34.46376702839382 
  "height : " 67.30487063268606 
  "fill : " "#fdbf6f"*/
  
    .on('mouseover', (d, i) => {
      const { name, category, value } = d.data;
      
      /*d.data: 
      category: "Product Design"
      name: "G-RO: Revolutionary Carry-on Luggage"
      value: "3307773"*/
      //console.log("d.data",d.data)
      
      /*pageX es un valor entero expresado en pixels para la coordenada X del puntero del ratón, relativo al documento entero, cuando se produjo el evento. Esta propiedad toma en cuenta la barra de desplazamiento horizontal de la página.*/
      tooltip.classList.add('show');
      tooltip.style.left = (d3.event.pageX)-200 + 'px';
      tooltip.style.top = (d3.event.pageY - 100) + 'px';
      tooltip.setAttribute('data-value', value);
      
 /*console.log("tooltip.style.left : ",d3.event.pageX,"tooltip.style.top : ",d3.event.pageY - 100)*/
    // EJ : left : -187, top : 255 , pageX : -187, pageY : 355
      
      tooltip.innerHTML = `
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Category:</strong> ${category}</p>
        <p><strong>Value:</strong> ${value}</p>
        <p><strong>left:</strong> ${tooltip.style.left}</p>
      `;
  }).on('mouseout', () => {
    tooltip.classList.remove('show');
  });

  cell.append('text')
    .selectAll('tspan') // sin selectAll los cuadrados estan sin texto.
  /*The SVG <tspan> element defines a subtext within a <text> element or another <tspan> element. It allows for adjustment of the style and/or position of that subtext as needed.*/
  // EJ probable de d.data.name : "Shenmue 3"
    .data(d => d.data.name.split(/(?=[A-Z][^A-Z])/g))
    .enter()
    .append('tspan') // sin enter o append los cuadrados estan sin texto.
    .attr('style', 'font-size: 9px')
    //.attr('style', 'font-family: Verdana')
    .attr('x', 4)
    .attr('y', (d, i) => 15 + i * 15) // ej : 45
    // sin text el texto en los cuadrados no se muestra.
    .text(d => d) // ej : "Kickstarter EVE"
   //.attr('fake5', (d) => console.log("d : ",d))
    //.attr('fake2', (d,i) => console.log("(d, i)",15 + i * 15)) // EJ : 45
  //.attr('fake3', (d,i) => console.log("  d",d,"  i",i)) // EJ : "  d" "Beer" "  i" 5
  
  /*El método indexOf() retorna el primer índice en el que se puede encontrar un elemento dado en el array, ó retorna -1 si el elemento no esta presente.*/
  const categories = root.leaves()
  .map(n => n.data.category)
  .filter((item, idx, arr) => arr.indexOf(item) === idx);
  // sin filter se repiten nombres como "product design y categories.length = 100."sin mapear el log es larguisimo y por lo tanto no se muestra.sin leaves el codigo no funciona.
   //console.log("categories",categories,"categories.length",categories.length)
  
  /*"categories" // [object Array] (19)
["Product Design","Tabletop Games","Gaming Hardware","Video Games","Sound","Television","Narrative Film","Web","Hardware","Games","3D Printing","Technology","Wearables","Sculpture","Apparel","Food","Art","Gadgets","Drinks"] 
"categories.length" 19*/

  // create the legend
  const blockSize = 20;
  const legendWidth = 200;
  const legendHeight = (blockSize + 2) * categories.length; // (20+2) * 19 = 418
  
  //console.log("legendHeight",legendHeight)
  
  const legend = d3.select('body')
    .append('svg')
    .attr('id', 'legend')
    .attr('width', legendWidth) // 200
    .attr('height', legendHeight) // 418
   
  legend.selectAll('rect')
    .data(categories)
    .enter()
    .append('rect')
    .attr('class', 'legend-item')
    .attr('fill', d => color(d)) // EJ : "fill" "#fdbf6f"
    .attr('x', blockSize / 2) // 10
    .attr('y', (_, i) => i * (blockSize + 1) + 10) // ej : 388
    .attr('width', blockSize) // 20
    .attr('height', blockSize) // 20
   //.attr('fake6', (_, i) => console.log("y (_, i)",i * (blockSize + 1) + 10)) // EJ : "y (_, i)" 388
  
   legend.append('g')
      .selectAll('text')
      .data(categories)
      .enter()
      .append('text')
      .attr('fill', 'orange')
      .attr('x', blockSize * 2) // 40
      .attr('y', (_, i) => i * (blockSize + 1) + 25) // ej : 403
   //.attr('fake7', (_, i) => console.log("y2 (_, i)",i * (blockSize + 1) + 25)) // EJ : "y2 (_, i)" 403
      .text(d => d) // EJ : "Product Design"
      //.attr('fake8', (d) => console.log(d))
}

run();